package com.example.siakad1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
